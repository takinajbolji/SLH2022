<?php
/*
 * @name zaglavlje logovanja
 * @author branko
 * @date   23.11.2022
 * @version 01
 *
 */
?>

<!DOCTYPE html>
<html lang="en, sr, el">

<head>
		<title>Scientists little helper</title>
		<?php include '../login/headLogovanje.php';?>

	<header>
	 <!-- naslovna traka -->
	 <div style="background-color:#e5e5e5; text-align:center; padding:1px;margin-top:1px; ">
		<div class="naslov-text">
			<h5>Dobro dosli u aplikaciju</h5>
  			<h2>Scientists little helper</h2>
		</div>
  	</div>		
    		
	<div class="line"></div>
	
 	</header>  	
