		
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1250">
		<meta http-equiv="content-type" content="text/html; charset=windows-1253" />
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	
  		<meta name="viewport" content="width=device-width, initial-scale=1.0">
  		
  			<!--  CSS -->
		
			<link rel="stylesheet" type="text/css" href="../dizajn/stil.css"> 
			<link rel="stylesheet" type="text/css" href="../dizajn/padajuciMeni.css"> 
	    	<link rel="stylesheet" type="text/css" href="../dizajn/moj.css">  
		
	 	
	 	<link rel="stylesheet" type="text/css" href="../dizajn/css/bootstrap.min.css">
	 	
</head> 